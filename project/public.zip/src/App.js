import React from 'react'

import Stopwatch from './Component/test1/Stopwatch';

const App = () => {
  return (
    <div>
  
     <Stopwatch/>

    </div>
  )
}
export default App;
