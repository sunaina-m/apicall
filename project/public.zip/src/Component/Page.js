import React, { useEffect, useState } from 'react'
import { Pagination } from '@mui/material';


const Page = () => {
  const [data, setData] = useState([])
  const[currentPage, setcurrentPage]=useState(1)
  const[currentPost, setcurrentPost]=useState(5)

  useEffect(() => {

    const fetchingData = fetch("https://fakestoreapi.com/products?")
    fetchingData.then((getdata) => {
      getdata.json().then((result) => {
        setData(result)
      })
    })
  }, [])
  const lastindexPost= currentPage *currentPost;
  const firstindexPost=lastindexPost-currentPost;
  const current =data.slice(firstindexPost,lastindexPost)

  console.log(data)
  const pageChange =(pageno)=>{
    setcurrentPage(pageno)
}
  return (
    <>
      <br></br>
      <h1>API data</h1>
      {
        current && current.length > 0 ?
          current.map(value =>
            <ul key={value.id}>
              <li>{value.id}</li>
              <li>{value.title}</li>
              <li>{value.description}</li>
              
             
              

            </ul>
          )
          : 'looding......'

      }
      <br></br>
      <Pagination count={5} variant="outlined" shape="rounded" className='page' onClick={pageChange} />

    </>
  )
}
export default Page;
