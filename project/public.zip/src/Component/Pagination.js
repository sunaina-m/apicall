import React from "react";
import { Pagination } from '@mui/material';

const Pagination =()=>{
    return(
        <>
        <Pagination count={5} variant="outlined" shape="rounded" className='page' onClick={pageChange} />
        </>
    )
}
export default Pagination;